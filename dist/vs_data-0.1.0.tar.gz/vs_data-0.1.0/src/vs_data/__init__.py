"""Vs Data."""
