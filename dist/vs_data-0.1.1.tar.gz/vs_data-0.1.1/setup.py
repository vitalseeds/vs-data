# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['vs_data', 'vs_data.cli', 'vs_data.fm', 'vs_data.stock', 'vs_data.wc']

package_data = \
{'': ['*'], 'vs_data.fm': ['queries/*']}

install_requires = \
['click>=8.1.3,<9.0.0',
 'pandas>=1.5.2,<2.0.0',
 'pypyodbc>=1.3.6,<2.0.0',
 'requests>=2.28.1,<3.0.0',
 'rich>=12.6.0,<13.0.0',
 'woocommerce>=3.0.0,<4.0.0']

entry_points = \
{'console_scripts': ['vsdata = vs_data.__main__:cli'],
 'vsdata': ['vsdata = vs_data.__main__:cli']}

setup_kwargs = {
    'name': 'vs-data',
    'version': '0.1.1',
    'description': 'Vital Seeds database website integration',
    'long_description': "# VS-data\n\nThis is a python library that serves as a bridge between inventory management in\nFileMaker, and order details on vitalseeds.co.uk.\n\nAims to replace opaque and proprietary FM 'scripts' - specifically where they\ninteract with the WooCommerce/WP website.\n\n\n## Requirements\n\nTo connect to Filemaker:\n\n- filemaker database\n- fm user configured with `all access`\n- ODBC manager instaleld and configured with a DSN for the db\n- Filemaker ODBC driver\n\nTo connect to WooCommerce:\n\n- [API credentials][wcapi]\n\n\n## Installation\n\n- `pip install ...(TBC)`\n- Set environment variables (these can also be passed as arguments eg when calling from FM)\n  - `VSDATA_FM_CONNECTION_STRING`\n  - `VSDATA_WC_URL`\n  - `VSDATA_WC_KEY`\n  - `VSDATA_WC_SECRET`\n\n## Rationale\n\n- FM scripts\n  - are quite error prone\n  - almost impossible to test and debug\n  - have extremely poor documentation\n  - have very limited and costly external support\n- python scripts can\n  - make use of robust third party libraries such as [WooCommerce][1]\n  - be version controlled\n  - use automated testing\n  - be edited and searched as text, ie with a full featured code editor like [VScode](https://code.visualstudio.com/)\n  - be **much** more performant\n  - be iterated and improved more simply\n\n[1]: https://pypi.org/project/WooCommerce/\n[wcapi]: https://woocommerce.com/document/woocommerce-rest-api/#section-2",
    'author': 'tombola',
    'author_email': 'thomas.readings@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
