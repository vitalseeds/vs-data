class FilemakerTable:
    """Named class to represent table/field name mappings"""

    pass
